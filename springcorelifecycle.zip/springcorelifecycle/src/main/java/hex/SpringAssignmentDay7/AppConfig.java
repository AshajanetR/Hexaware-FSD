package hex.SpringAssignmentDay7;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
   @Bean
   public Project getProject() {
	   Project p = new Project();
	   p.setpId(1);
	   p.setDuration("30 days");
	   p.setCost(500000);
	   return p;
   }
   
   @Bean
   public Employee getEmployee() {
	   Employee e = new Employee();
       e.setEmpId(102);
       e.setName("Annie");
       e.setSalary(90000);
       e.setProject(getProject());

       Map<String, String> addr = new HashMap<>();
       addr.put("home", "456 sugarcane apartments");
       addr.put("office", "hsr data Center");
       e.setAddress(addr);
	   return e;
   }
}
