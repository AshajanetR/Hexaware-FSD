package hex.SpringAssignmentDay7;



import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
      
    	AbstractApplicationContext con = new ClassPathXmlApplicationContext("beans.xml"); 
    	con.registerShutdownHook();
    	Employee e =(Employee)con.getBean("e1");
        System.out.println(e.toString());
        con.close();
        
        System.out.println("-------------------");
        
        AbstractApplicationContext con1 =  new AnnotationConfigApplicationContext(AppConfig.class);
        con1.registerShutdownHook();
        Employee emp = (Employee) con1.getBean("getEmployee");
        System.out.println(emp.toString());
        
    }
}
