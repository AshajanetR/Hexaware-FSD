package hex.SpringAssignmentDay7;

import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Employee implements InitializingBean,DisposableBean{
   int empId;
   String name;
   double salary;
   Map<String,String> address;
   @Autowired
   Project project;
   
   Employee(){
	   
   }
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public Map<String, String> getAddress() {
	return address;
}
public void setAddress(Map<String, String> address) {
	this.address = address;
}
public Project getProject() {
	return project;
}
public void setProject(Project project) {
	this.project = project;
}
public Employee(int empId, String name, double salary, Map<String, String> address, Project project) {
	this.empId = empId;
	this.name = name;
	this.salary = salary;
	this.address = address;
	this.project = project;
}
@Override
public String toString() {
	return "Employee [empId=" + empId + ", name=" + name + ", salary=" + salary + ", address=" + address + ", project="
			+ project + "]";
}
@Override
public void destroy() throws Exception {
	// TODO Auto-generated method stub
	System.out.println("Ended using destroy.....\n");
}
@Override
public void afterPropertiesSet() throws Exception {
	// TODO Auto-generated method stub
	System.out.println("Started using afterPropertiesSet...\n");
}
@PostConstruct
public void start() {
	System.out.println("initialized using postConstruct.......\n");
}
@PreDestroy
public void end() {
	System.out.println("finished using preDestroy.......\n");
} 
}
