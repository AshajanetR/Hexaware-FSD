package Service;

import java.util.Scanner;

import Dao.StudentDao;
import Model.Student;

public class StudentService {
	
	Student s;
	StudentDao dao;
	Scanner sc;
	
	
	public StudentService(){
		s = new Student();
		sc =new Scanner(System.in);
		dao = new StudentDao();
	}
	
	public void saveStudent() {
		
		System.out.println("Enter roll no");
		s.setRollno(sc.nextInt());
		
		System.out.println("Enter name");
		s.setName(sc.next());
		
		System.out.println("Enter marks ");
		s.setMarks(sc.nextDouble());
		
		dao.saveData(s);
	}
	
	public void removeStudent() {
		System.out.println("Enter roll no ");
		int rno = sc.nextInt();
		
		dao.removeData(rno);
	}
	
	public void updateStudent() {
		System.out.println("Enter roll no");
		int rno = sc.nextInt();
		
		System.out.println("Enter name : ");
		String name = sc.next();
		
		System.out.println("Enter marks : ");
		double marks = sc.nextDouble();
		
		dao.updateData(rno, name, marks);
	}
	
	public void searchStudent() {
		System.out.println("Enter roll no : ");
		int rno = sc.nextInt();
		
		dao.searchData(rno);
	}
	
	public void showAll() {
		dao.showData();
	}
	
	public void searchbyName() {
		System.out.println("Enter name : ");
		String name = sc.next();
		
		dao.searchbyName(name);
	}
	
	public void searchbyNameMarks() {
		System.out.println("Enter name");
		String nm = sc.next();
		
		System.out.println("Enter marks : ");
		double marks = sc.nextDouble();
		
		dao.searchbyNameMarks(nm, marks);
	}
	
	public void searchbyMarks() {
		System.out.println("Enter marks");
		double mr = sc.nextDouble();
		
		dao.searchbyMarks(mr);
	}
	
	public void removeDataHQL() {
		System.out.println("Enter roll no");
		int rn = sc.nextInt();
		
		dao.removeDataHQL(rn);
	}
	
	public void updateHQL() {
		System.out.println("Enter roll no : ");
		int rn = sc.nextInt();
		
		System.out.println("Enter name : ");
		String nm = sc.next();
		
		System.out.println("Enter marks");
		double mk = sc.nextDouble();
		
		dao.updateHQL(rn, nm, mk);
	}

}
