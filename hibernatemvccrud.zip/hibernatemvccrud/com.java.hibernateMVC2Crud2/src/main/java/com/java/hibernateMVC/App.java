package com.java.hibernateMVC;

import Model.Student;
import Service.StudentService;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    { 
    	
    	StudentService service = new StudentService();
//    	service.saveStudent();
//    	service.removeStudent();
//    	service.updateStudent();
//    	service.searchStudent();
//    	service.showAll();
    	service.searchbyName();
//    	service.searchbyNameMarks();
//    	service.searchbyMarks();
//    	service.removeDataHQL();
//    	service.updateHQL();
        System.out.println( "Hello World!" );
    }
}
