package Dao;

import Model.Student;

public interface DaoStudentI {
	
	void saveData(Student s);
	void removeData(int rollno);
	void updateData(int rollno,String name,double marks);
	void searchData(int rollno);
	void showData();
	void searchbyName(String name);
	void searchbyNameMarks(String name, double marks);
	void searchbyMarks(double marks);
	void removeDataHQL(int rollno);
	void updateHQL(int rollno, String name, double marks);

}
