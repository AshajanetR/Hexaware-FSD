package Dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.Query;

import Connection.StudentConnection;
import Model.Student;

public class StudentDao implements DaoStudentI{

	 
	SessionFactory factory;
	
	public StudentDao(){
		factory = StudentConnection.getSessionFactory();
	}
	
	@Override
	public void saveData(Student s) {
		// TODO Auto-generated method stub
		
		Session session = factory.openSession();
		Transaction txt = session.beginTransaction();
		 
		session.save(s);
		txt.commit();
		
		
	}

//	@Override
//	public void removeData(int rollno) {
//		// TODO Auto-generated method stub
//		
//		Session session = factory.openSession();
//		Transaction txt = session.beginTransaction();
//		
//		NativeQuery<Student>s = session.createNativeQuery("delete from Student where rollno =:rollno", Student.class);
//		s.setParameter("rollno", rollno);
//		int r = s.executeUpdate();
//		
//		if(r>0) {
//			System.out.println("Removed");
//		}else {
//			System.out.println("Not found");
//		}
//		txt.commit();
//		
//	}
	
	@Override
	public void removeData(int rollno) {
		// TODO Auto-generated method stub
		
		Session session = factory.openSession();
		Transaction txt = session.beginTransaction();
		
		Query<Student>s = session.createNamedQuery("Student.removeByRoll");
		s.setParameter("rollno", rollno);
		int r = s.executeUpdate();
		
		if(r>0) {
			System.out.println("Removed");
		}else {
			System.out.println("Not found");
		}
		txt.commit();
		
	}


	@Override
	public void updateData(int rollno,String name,double marks) {
		// TODO Auto-generated method stub
		
		Session session = factory.openSession();
		Transaction txt = session.beginTransaction();
		
		NativeQuery<Student>s = session.createNativeQuery("update Student set name =:name, marks=:marks where rollno =:rollno", Student.class);
		s.setParameter("rollno", rollno);
		s.setParameter("name", name);
		s.setParameter("marks", marks);
		
		int r = s.executeUpdate();
		
		if(r>0) {
			System.out.println("Updated");
		}else {
			System.out.println("Not found");
		}
		txt.commit();
		
	}

	@Override
	public void searchData(int rollno) {
		// TODO Auto-generated method stub
		
		Session session = factory.openSession();
		Transaction txt = session.beginTransaction();
		
		Student s = session.find(Student.class, rollno);
		
		if(s!= null) {
			System.out.println(s.toString());
		}else {
			System.out.println("Not found");
		}
		
		txt.commit();
		
	}

	@Override
//	public void showData() {
//		// TODO Auto-generated method stub
//		
//		Session session = factory.openSession();
//		NativeQuery<Student>q = session.createNativeQuery("select * from Student", Student.class);
//		List<Student> qlist = q.list();
//		
//		for (Student student : qlist) {
//			System.out.println(student.toString());
//		}
//		
//	}
	
	public void showData() {
		// TODO Auto-generated method stub
		
		Session session = factory.openSession();
		Query<Student>q = session.createNamedQuery("Student.findAll", Student.class);
		List<Student> qlist = q.list();
		
		for (Student student : qlist) {
			System.out.println(student.toString());
		}
		
	}
	

//	@Override
//	public void searchbyName(String name) {
//		// TODO Auto-generated method stub
//		Session session = factory.openSession();
//		Query<Student> q = session.createQuery("from Student where name =:name",Student.class);
//		q.setParameter("name", name);
//		List<Student>qlist = q.list();
//		
//		for (Student student : qlist) {
//			System.out.println(student.toString());
//		}
//		
//	}
	
	@Override
	public void searchbyName(String name) {
		// TODO Auto-generated method stub
		Session session = factory.openSession();
		Query<Student> q = session.createNamedQuery("Student.findByname", Student.class);
		q.setParameter("name", name);
		List<Student>qlist = q.list();
		
		for (Student student : qlist) {
			System.out.println(student.toString());
		}
		
	}
	

	@Override
	public void searchbyNameMarks(String name, double marks) {
		// TODO Auto-generated method stub
		Session session = factory.openSession();
		Query<Student>q = session.createQuery("from Student where name =: name and marks =: marks",Student.class);
		q.setParameter("name", name);
		q.setParameter("marks", marks);
		
		List<Student>qlist = q.list();
		
		for (Student student : qlist) {
			System.out.println(student.toString());
		}
		
	}

	@Override
	public void searchbyMarks(double marks) {
		// TODO Auto-generated method stub
		
		Session session = factory.openSession();
		Query<Student>q = session.createQuery("from Student where marks >: marks",Student.class);
		q.setParameter("marks", marks);
		List<Student>qlist = q.list();
		
		qlist.stream().forEach((i)->System.out.println(i.toString()));
		
	}

	@Override
	public void removeDataHQL(int rollno) {
		// TODO Auto-generated method stub
		Session session = factory.openSession();
		Transaction txt = session.beginTransaction();
		Query<Student>q = session.createQuery("delete from Student where rollno =: rollno");
		q.setParameter("rollno", rollno);
		int r = q.executeUpdate();
		
		if(r>0) {
			System.out.println("Removed");
		}else {
			System.out.println("Not found");
		}
		
		txt.commit();
		
	}

	@Override
	public void updateHQL(int rollno, String name, double marks) {
		// TODO Auto-generated method stub
		
		Session session = factory.openSession();
		Transaction txt = session.beginTransaction();
		
		Query<Student>q = session.createQuery("update Student set name =: name, marks =: marks where rollno =: rollno");
		q.setParameter("rollno", rollno);
		q.setParameter("name", name);
		q.setParameter("marks", marks);
		
		int r = q.executeUpdate();
		
		if(r> 0) {
			System.out.println("Updated");
		}else {
			System.out.println("Not found");
		}
		txt.commit();
		
	}
	
	

}
