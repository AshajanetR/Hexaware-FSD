package hex.mapping.hex.mappingExample;

import jakarta.persistence.Embeddable;

@Embeddable
public class class2 {
    int sid;
    String sport;

    public class2() {
    }

    public class2(int sid, String sport) {
        this.sid = sid;
        this.sport = sport;
    }

    public int getSid() {
        return sid;
    }

    public void setSid(int sid) {
        this.sid = sid;
    }

    public String getSport() {
        return sport;
    }

    public void setSport(String sport) {
        this.sport = sport;
    }

    @Override
    public String toString() {
        return "class2 [sid=" + sid + ", sport=" + sport + "]";
    }
}
