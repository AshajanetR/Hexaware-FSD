package hex.mapping.hex.mappingExample;

import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class class1 {

    @Id
    int rno;
    String name;

    @Embedded
    class2 sports;  

    public class1() {
    }

    public class1(int rno, String name, class2 sports) {
        this.rno = rno;
        this.name = name;
        this.sports = sports;
    }

    public int getRno() {
        return rno;
    }

    public void setRno(int rno) {
        this.rno = rno;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public class2 getSports() {
        return sports;
    }

    public void setSports(class2 sports) {
        this.sports = sports;
    }

    @Override
    public String toString() {
        return "class1 [rno=" + rno + ", name=" + name + ", sports=" + sports + "]";
    }
}
