package hex.mapping.hex.mappingExample;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity
public class Book {
	
	@Id
     int bid;
     String name;
     String genre;
     double price;
     
     @OneToOne(targetEntity =Author.class,cascade = CascadeType.ALL)
     Author author;
     public Book(){
    	 
     }
	public Book(int bid, String name, String genre, double price, Author author) {
		this.bid = bid;
		this.name = name;
		this.genre = genre;
		this.price = price;
		this.author = author;
	}
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Author getAuthor() {
		return author;
	}
	public void setAuthor(Author author) {
		this.author = author;
	}
	@Override
	public String toString() {
		return "Book [bid=" + bid + ", name=" + name + ", genre=" + genre + ", price=" + price + ", author=" + author
				+ "]";
	}
	
     
     
}
