package hex.mapping.hex.mappingExample;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Customer {
	@Id
      int cid;
      String name;
      @OneToMany(targetEntity = Account.class,cascade =CascadeType.ALL)
     List<Account> account;
      
     public Customer() {
    	
    }
	public Customer(int cid, String name, List<Account> account) {
		this.cid = cid;
		this.name = name;
		this.account = account;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Account> getAccount() {
		return account;
	}
	public void setAccount(List<Account> account) {
		this.account = account;
	}
	@Override
	public String toString() {
		return "Customer [cid=" + cid + ", name=" + name + ", account=" + account + "]";
	}
	
      
      
}
