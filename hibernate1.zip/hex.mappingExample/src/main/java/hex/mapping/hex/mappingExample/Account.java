package hex.mapping.hex.mappingExample;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Account {
	@Id
      int aid;
      String type;
      double balance;
      
      public Account() {
    	  
      }
	public Account(int aid, String type, double balance) {
		this.aid = aid;
		this.type = type;
		this.balance = balance;
	}
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [aid=" + aid + ", type=" + type + ", balance=" + balance + "]";
	}
      
      
}
