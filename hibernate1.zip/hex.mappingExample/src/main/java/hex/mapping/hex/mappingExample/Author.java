package hex.mapping.hex.mappingExample;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Author {
	@Id
    int aid;
    String name;
    
    public Author() {
    	
    }
	public Author(int aid, String name) {
		this.aid = aid;
		this.name = name;
	}
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Author [aid=" + aid + ", name=" + name + "]";
	}
    
}
