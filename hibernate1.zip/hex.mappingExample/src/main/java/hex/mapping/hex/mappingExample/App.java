package hex.mapping.hex.mappingExample;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	SessionFactory sessionFactory= new Configuration().
    			   configure("hiber.config.xml").
    			   addAnnotatedClass(class1.class).
//    			   addAnnotatedClass(Address.class).
    			   buildSessionFactory();
    	
    	
    	   Session session = sessionFactory.openSession();
    	   Transaction txt =session.beginTransaction();
    	   
    	   class2 sport = new class2();
    	   sport.setSid(1);
    	   sport.setSport("basketball");
    	   
    	   class1 s = new class1();
    	   s.setRno(1);
    	   s.setName("asha");
    	   s.setSports(sport);
    	   session.save(s);
    	   txt.commit();
    	   
//           
    	   
    	
    	   
//
//           Department  d= session.get(Department.class, 1);
//
//           System.out.print( d.getdName());
//       System.out.print(d.getEmplist());
    	
    	
//    	   Account a1 = new Account();
//    	   a1.setAid(1);
//    	   a1.setType("current");
//    	   a1.setBalance(2000);
//    	   
//    	   Account a2 = new Account();
//    	   a2.setAid(2);
//    	   a2.setType("savings");
//    	   a2.setBalance(3000);
//    	   
//    	   List<Account> list= new ArrayList();
//    	   list.add(a1);
//    	   list.add(a2);
//    	   
//    	   
//    	   Customer c = new Customer();
//    	   c.setCid(1);
//    	   c.setName("asha");
//    	   c.setAccount(list);
//    	   session.save(c);
//    	   
//    	   txt.commit();
    	   
    	   
    	   
//    	   Employee e1= new Employee(103,"robert",4000.0);
//           Employee e2= new Employee(104,"mary",8000.0);
// 
//          
//          List<Employee> list= new ArrayList();
//          list.add(e1);
//          list.add(e2);
//
//          Department ojbD= new Department();
//          ojbD.setdCode(2);
//          ojbD.setdName("Tech");
//          ojbD.setEmplist(list);
//
//          session.save(ojbD);
//          txt.commit();
           
           
//           Address a1= new Address();
//           a1.setAddressid(1);
//           a1.setCity("bombay");
//           
//           
//           Student s1 = new Student();
//           s1.setRollno(101);
//           s1.setName("Ajay");
//           s1.setAddress(a1);
//           
//           
//           
//           session.save(s1);
//           txt.commit();
//           
//    	   
//    	   Author a= new Author();
//    	   a.setAid(2);
//    	   a.setName("janet");
////    	   session.save(a);
//    	   
//    	   Book b = new Book();
//    	   b.setBid(2);
//    	   b.setName("alice in borderland");
//    	   b.setGenre("adventure");
//    	   b.setPrice(3000);
//    	   b.setAuthor(a);
//    	   
//    	   session.save(b);
//    	   txt.commit();
//    }
}
}
