package Connection;


import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import Model.Book;

public class BooksConnection {
	
	private static SessionFactory sessionfactory;
	
	BooksConnection(){
		
		sessionfactory = new Configuration().configure("hiber.config.xml").addAnnotatedClass(Book.class).buildSessionFactory();
	}
	
	
	public static SessionFactory getSessionfactory() {
		BooksConnection bookscon = new BooksConnection();
		return sessionfactory;
	}

}

