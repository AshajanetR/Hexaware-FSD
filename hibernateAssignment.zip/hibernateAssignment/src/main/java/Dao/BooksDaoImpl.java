package Dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import Connection.BooksConnection;
import Model.Book;

public class BooksDaoImpl implements BooksDao{
	
	SessionFactory factory;
	
	public BooksDaoImpl() {
		factory = BooksConnection.getSessionfactory();
	}
	

	@Override
	public void addBook(Book book) {
		// TODO Auto-generated method stub
		
		Session session = factory.openSession();
		Transaction txt = session.beginTransaction();
		
		session.save(book);
		txt.commit();
		
		
	}


	@Override
	public void updatePrice(int bookid,double price) {
		// TODO Auto-generated method stub
		Session session = factory.openSession();
		Transaction txt = session.beginTransaction();
		
		Query<Book>b = session.createQuery("update Book set price =: price where bookid =: bookid");
		b.setParameter("bookid", bookid);
		b.setParameter("price", price);
		
		int r = b.executeUpdate();
		
		if(r>0) {
			System.out.println("Updated");
		}else {
			System.out.println("Not found");
		}
		
		txt.commit();
		
	}


	@Override
	public void removeBook(int bookid) {
		// TODO Auto-generated method stub
		
		Session session = factory.openSession();
		Transaction txt = session.beginTransaction();
		
		Query<Book>b = session.createQuery("delete from Book where bookid =: bookid");
		b.setParameter("bookid", bookid);
		int r = b.executeUpdate();
		
		if(r>0) {
			System.out.println("Removed");
		}else {
			System.out.println("Not found");
		}
		txt.commit();
		
		
	}


	@Override
	public void enquiryBook(int bookid) {
		// TODO Auto-generated method stub
		Session session = factory.openSession();
		Transaction txt = session.beginTransaction();
		Query<Book>b = session.createQuery("from Book where bookid =: bookid");
		b.setParameter("bookid", bookid);
		List<Book>blist = b.list();
		
		for (Book book : blist) {
			System.out.println(book.toString());
		}
		
	}


	@Override
	public void generateBill(int bookid, int quantity) {
		// TODO Auto-generated method stub
		Session session = factory.openSession();
		Transaction txt = session.beginTransaction();
		Query<Double>priceQ = session.createQuery("select price from Book where bookid =: bookid");
		priceQ.setParameter("bookid", bookid);
		Double price = priceQ.getSingleResult();
		double bill = quantity*price;
		System.out.println("Total bill is : "+bill);
		
	}

}
