package Dao;

import Model.Book;

public interface BooksDao {
	void addBook(Book book);
	void updatePrice(int bookid,double price);
	void removeBook(int bookid);
	void enquiryBook(int bookid);
	void generateBill(int bookid, int quantity);
}
