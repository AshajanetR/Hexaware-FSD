package hibernateAssignment.hibernateAssignment;

import Service.BooksService;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
BooksService service = new BooksService();
    	
//    	service.addBook();
//    	service.updateBook();
    	service.removeBook();
//    	service.enquiryBook();
//    	service.generateBill();
    }
}
