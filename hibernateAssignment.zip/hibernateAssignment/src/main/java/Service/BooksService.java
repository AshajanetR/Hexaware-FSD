package Service;

import java.util.Scanner;
import Dao.BooksDaoImpl;
import Model.Book;

public class BooksService {

    Book b;
    BooksDaoImpl dao;

    public BooksService() {
        b = new Book();
        dao = new BooksDaoImpl();
    }

    public void addBook() {
        System.out.println("Enter book id");
        int bi = new Scanner(System.in).nextInt();
        b.setBookid(bi);

        System.out.println("Enter book title");
        String bt = new Scanner(System.in).next();
        b.setTitle(bt);

        System.out.println("Enter book author");
        String ba = new Scanner(System.in).next();
        b.setAuthor(ba);

        System.out.println("Enter book price ");
        double bp = new Scanner(System.in).nextDouble();
        b.setPrice(bp);

        System.out.println("Enter book quantity ");
        int bq = new Scanner(System.in).nextInt();
        b.setQuantity(bq);

        dao.addBook(b);
    }

    public void updateBook() {
        System.out.println("Enter book id : ");
        int bi = new Scanner(System.in).nextInt();

        System.out.println("Enter updated price : ");
        double bp = new Scanner(System.in).nextDouble();

        dao.updatePrice(bi, bp);
    }

    public void removeBook() {
        System.out.println("Enter book id : ");
        int bi = new Scanner(System.in).nextInt();

        dao.removeBook(bi);
    }

    public void enquiryBook() {
        System.out.println("Enter book id : ");
        int bi = new Scanner(System.in).nextInt();

        dao.enquiryBook(bi);
    }

    public void generateBill() {
        System.out.println("Enter book id :");
        int bi = new Scanner(System.in).nextInt();

        System.out.println("Enter quantity : ");
        int bq = new Scanner(System.in).nextInt();

        dao.generateBill(bi, bq);
    }
}
